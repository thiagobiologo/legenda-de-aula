// Barra lateral: escuta o "microfone" do Chrome (use o CABLE Output), transcreve (reconhecimento do Chrome),
// junta em frases, traduz a frase inteira (contexto) e mostra em português. Salva em .md.
const $ = id => document.getElementById(id);
let ui = 'pt';   // idioma da própria barra (pt/es); começa pelo idioma do navegador
try { ui = localStorage.getItem('ui') || ((navigator.language || '').toLowerCase().startsWith('es') ? 'es' : 'pt'); } catch (e) { /* ok */ }
const L = (pt, es) => (ui === 'es' ? es : pt);
const GAP_MS = 1400;          // pausa que fecha uma frase
const SPLIT_CHARS = 170;      // bloco já finalizado e longo: fecha para ficar legível
const FORCE_CHARS = 260;      // sem pausa nenhuma: força o Chrome a finalizar
const COLORS = ['#6aa9ff', '#ff9e64', '#7ee08a', '#e58bff', '#ffd166'];

let running = false, rec = null, stream = null, actx = null, analyser = null, timers = [];
let units = [], names = {}, startedAt = Date.now();
let cur = null;               // frase em andamento
let f0buf = [];               // {t, f0}
let lastAudioAt = 0, level = 0, restarts = [];
let sessResults = null, baseIdx = 0;   // lista de resultados do Chrome e de onde começa a frase atual
const speakers = new Core.Speakers();
let lastCloseAt = 0;
let dir = 'es2pt';   // es2pt: aula em espanhol traduzida para português; pt2es: o contrário
let langNow = 'es', lowRun = 0, sinceSwitch = 99;   // idioma em uso, confiança baixa seguida, frases desde a última troca
const LOW_CONF = 0.65;
const foreignLang = () => (dir === 'es2pt' ? 'es' : 'pt');           // idioma que é traduzido
const needsTr = () => langNow === foreignLang();                      // o idioma nativo nunca é traduzido
const recLang = () => (langNow === 'pt' ? 'pt-BR' : $('lang').value);
const dirLabel = () => (dir === 'es2pt' ? L('espanhol → português', 'español → portugués') : L('português → espanhol', 'portugués → español'));
let chain = Promise.resolve(); // fecha frases em ordem
let lastResultAt = Date.now(), recStartAt = 0, recGen = 0, backoff = 150, recRestarts = 0, dropped = 0;
const SILENT_LEVEL = 0.006;   // abaixo disso a "fala" reconhecida é invenção do Chrome (alucinação no silêncio)

function newCur() { return { id: Math.random(), t0: Date.now(), pt: '', lastAct: Date.now(), trFor: null, peak: 0 }; }
// Tira repetição de palavra que o Chrome inventa ("gracias gracias gracias gracias gracias").
function cleanText(t) { return t.replace(/\b([\p{L}']+)(?:\s+\1\b){2,}/giu, '$1 $1').trim(); }
function segParts() {
  let text = '', allFinal = true, cs = 0, cn = 0;
  if (sessResults) for (let i = baseIdx; i < sessResults.length; i++) {
    const r = sessResults[i]; text += ' ' + r[0].transcript.trim(); if (!r.isFinal) allFinal = false;
    else if (r[0].confidence > 0) { cs += r[0].confidence; cn++; }
  }
  return { text: text.replace(/\s+/g, ' ').trim(), allFinal, conf: cn ? cs / cn : 0 };
}
const curText = () => segParts().text;

function setStatus(msg, cls) { const s = $('status'); s.textContent = msg; s.className = cls || ''; }

// ---------- tradução ----------
const localTrs = {}; // por direção; undefined = não verificado; null = indisponível
async function getLocal() {
  const d = dir;
  if (localTrs[d] !== undefined) return localTrs[d];
  localTrs[d] = null;
  const sl = d === 'es2pt' ? 'es' : 'pt', tl = d === 'es2pt' ? 'pt' : 'es';
  try {
    if (self.Translator && (await Translator.availability({ sourceLanguage: sl, targetLanguage: tl })) === 'available')
      localTrs[d] = await Translator.create({ sourceLanguage: sl, targetLanguage: tl });
  } catch (e) { localTrs[d] = null; }
  return localTrs[d];
}
async function tr(text) {
  if (!text.trim()) return '';
  const l = await getLocal();
  if (l) {
    try { return await withTimeout(l.translate(text), 5000); } catch (e) { /* cai para o Google */ }
  }
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 6000);   // sem isso, uma requisição pendurada trava tudo
  try {
    const url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=' + (dir === 'es2pt' ? 'es' : 'pt') + '&tl=' + (dir === 'es2pt' ? 'pt' : 'es') + '&dt=t&q=' + encodeURIComponent(text);
    const r = await fetch(url, { signal: ctl.signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json();
    return j[0].map(p => p[0]).join('');
  } finally { clearTimeout(to); }
}
function withTimeout(p, ms) {
  return Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('tempo esgotado')), ms))]);
}

// ---------- tela ----------
const log = $('log');
function colorOf(sp) { return COLORS[(sp - 1) % COLORS.length]; }
function nameOf(sp) { return names[sp] || ('Voz ' + sp); }
function unitNode(u, live) {
  const d = document.createElement('div'); d.className = 'u' + (live ? ' live' : '');
  const who = document.createElement('span'); who.className = 'who'; who.dataset.sp = u.sp;
  who.style.color = colorOf(u.sp); who.textContent = nameOf(u.sp); who.title = L('Clique para renomear', 'Haz clic para renombrar');
  who.onclick = () => rename(u.sp);
  const tm = document.createElement('span'); tm.className = 'time';
  tm.textContent = Core.fmtTime(u.t) + (u.conf ? ' · ' + Math.round(u.conf * 100) + '%' : '') + (u.nt ? ' · ' + (u.lang || '').toUpperCase() : '');
  const pt = document.createElement('div'); pt.className = 'pt'; pt.textContent = u.pt || u.es || '…';
  const es = document.createElement('div'); es.className = 'es'; es.textContent = u.es;
  d.append(who, tm, pt, es);
  const tg = u.tags || [];
  if (tg.length || u.nt) {
    if (tg.length) d.classList.add('hi');
    const bd = document.createElement('div'); bd.className = 'badges';
    for (const k of tg) { const b = document.createElement('span'); b.className = 'b'; b.textContent = Core.tagLabel(k, ui); bd.appendChild(b); }
    if (u.nt) { const b = document.createElement('span'); b.className = 'b ptb'; b.textContent = (u.lang === 'pt' ? L('português', 'portugués') : L('espanhol', 'español')) + L(' (não traduzido)', ' (sin traducir)'); bd.appendChild(b); }
    d.appendChild(bd);
  }
  return d;
}
function atBottom() { return log.scrollHeight - log.scrollTop - log.clientHeight < 90; }
function renderLive() {
  let n = document.getElementById('liveNode');
  if (!cur || !curText()) { if (n) n.remove(); return; }
  const stick = atBottom();
  const u = { t: cur.t0, sp: speakers.last ? speakers.last.id : 1, es: curText(), pt: cur.pt };
  const node = unitNode(u, true); node.id = 'liveNode';
  if (n) n.replaceWith(node); else log.appendChild(node);
  if (stick) log.scrollTop = log.scrollHeight;
}
function renderAll() {
  log.innerHTML = '';
  for (const u of units) log.appendChild(unitNode(u, false));
  renderLive(); log.scrollTop = log.scrollHeight;
  $('count').textContent = units.length + ' frases';
}
function rename(sp) {
  const v = prompt(L('Nome para "' + nameOf(sp) + '":', 'Nombre para "' + nameOf(sp) + '":'), nameOf(sp));
  if (!v) return;
  names[sp] = v.trim(); persist();
  document.querySelectorAll('.who[data-sp="' + sp + '"]').forEach(e => { e.textContent = names[sp]; });
}

// ---------- armazenamento ----------
function persist() { try { chrome.storage.local.set({ units, names, startedAt }); } catch (e) { /* ignora */ } }

// ---------- fechar frase / traduzir ----------
let pumping = false;
async function pump() {
  if (pumping) return; pumping = true;
  try {
    while (cur) {
      const c = cur, text = curText();
      if (!text || text === c.trFor) break;
      if (!needsTr()) { c.pt = text; c.trFor = text; renderLive(); break; }   // o idioma nativo nunca é traduzido
      let pt;
      try { pt = await tr(text); }
      catch (e) { setStatus(L('Tradução falhou (' + e.message + '). Mostrando o original; tentando de novo.', 'Falló la traducción (' + e.message + '). Mostrando el original; reintentando.'), 'warn'); await new Promise(r => setTimeout(r, 1500)); continue; }
      c.trFor = text;
      if (cur === c) { c.pt = pt; renderLive(); }
      await new Promise(r => setTimeout(r, 200));
    }
  } finally { pumping = false; }
}

function closeUnit() {
  const c = cur, parts = segParts(), conf = parts.conf;
  const text = cleanText(parts.text);
  baseIdx = sessResults ? sessResults.length : 0;   // o que já foi usado não volta nunca mais
  cur = null;
  const live = document.getElementById('liveNode'); if (live) live.remove();
  if (!c || !text) return;
  const prev0 = units[units.length - 1];
  if (running && c.peak < SILENT_LEVEL) { dropped++; return; }                       // texto sem som de verdade: invenção
  if (conf > 0 && conf < 0.3 && text.length < 25) { dropped++; return; }              // palpite fraquíssimo e curto
  if (prev0 && prev0.es === text && Date.now() - lastCloseAt < 8000) { dropped++; return; }   // repetição idêntica
  const now = Date.now();
  const f0s = f0buf.filter(x => x.t >= c.t0 - 200 && x.t <= now).map(x => x.f0);
  const sp = speakers.assign(f0s).id;
  const prev = units[units.length - 1];
  if (prev && prev.lang === langNow && text.length < 22 && now - lastCloseAt < 4500) {    // fragmento solto: junta com a frase anterior
    prev.es += ' ' + text; prev.pt = needsTr() ? '' : prev.es; lastCloseAt = now; persist();
    const pn = log.querySelectorAll('.u:not(.live)'); const pnode = pn[pn.length - 1];
    if (pnode) { pnode.querySelector('.es').textContent = prev.es; if (!needsTr()) pnode.querySelector('.pt').textContent = prev.es; }
    if (needsTr()) (async () => {
      for (let k = 0; k < 3 && !prev.pt; k++) { try { prev.pt = await tr(prev.es); } catch (e) { await new Promise(r => setTimeout(r, 1200)); } }
      if (prev.pt && pnode) { pnode.querySelector('.pt').textContent = prev.pt; persist(); }
    })();
    return;
  }
  lastCloseAt = now;
  const u = { t: c.t0, sp, es: text, pt: needsTr() ? (c.trFor === text ? c.pt : '') : text, lang: langNow, nt: !needsTr(), conf };
  u.tags = Core.findTags(u.es, u.pt);
  units.push(u); persist();
  const stick = atBottom();
  let node = unitNode(u, false); log.appendChild(node);   // entra na tela NA HORA, sem esperar tradução
  if (stick) log.scrollTop = log.scrollHeight;
  $('count').textContent = units.length + ' frases';
  if (!u.pt) (async () => {
    for (let k = 0; k < 3 && !u.pt; k++) {
      try { u.pt = await tr(text); } catch (e) { await new Promise(r => setTimeout(r, 1200)); }
    }
    if (u.pt) { u.tags = Core.findTags(u.es, u.pt); const nn = unitNode(u, false); node.replaceWith(nn); node = nn; persist(); }
  })();
  considerSwitch(conf);
}

// Troca automática de idioma pela confiança do reconhecimento (é um palpite; o seletor manual sempre vence).
function considerSwitch(conf) {
  sinceSwitch++;
  if ($('mode').value !== 'auto' || !conf) return;
  lowRun = conf < LOW_CONF ? lowRun + 1 : 0;
  if (lowRun >= 3 && sinceSwitch >= 5) setLang(langNow === 'es' ? 'pt' : 'es');
}
function refreshChip() {
  const chip = $('chip');
  chip.textContent = needsTr() ? (dir === 'es2pt' ? 'ES → PT' : 'PT → ES') : (langNow === 'pt' ? 'PT' : 'ES') + L(' · sem tradução', ' · sin traducción');
  chip.className = 'chip' + (needsTr() ? '' : ' ptmode');
}
function applyUi() {
  document.documentElement.lang = ui === 'es' ? 'es' : 'pt-BR';
  document.querySelectorAll('[data-es]').forEach(e => { if (e.dataset.pt === undefined) e.dataset.pt = e.textContent; e.textContent = ui === 'es' ? e.dataset.es : e.dataset.pt; });
  if (running) $('go').textContent = L('■ Parar', '■ Detener');
  refreshChip();
}
function setLang(l) {
  langNow = l; lowRun = 0; sinceSwitch = 0;
  refreshChip();
  if (rec) { rec.lang = recLang(); try { rec.stop(); } catch (e) { /* onend reinicia */ } }
}

function onResult(ev) {
  sessResults = ev.results; lastResultAt = Date.now(); backoff = 150;
  const { text, allFinal } = segParts();
  if (!text) return;
  if (!cur) cur = newCur();
  cur.lastAct = Date.now();
  if (allFinal && text.length >= SPLIT_CHARS) { closeUnit(); return; }
  if (!allFinal && text.length > FORCE_CHARS) { try { rec.stop(); } catch (e) { /* ok */ } }  // onend fecha e reinicia
  renderLive(); pump();
}

// ---------- reconhecimento ----------
function startRec() {
  const SR = self.SpeechRecognition || self.webkitSpeechRecognition;
  if (!SR) { setStatus(L('Este navegador não tem reconhecimento de fala. Use o Google Chrome.', 'Este navegador no tiene reconocimiento de voz. Usa Google Chrome.'), 'err'); return false; }
  const gen = ++recGen, r = new SR();
  rec = r;
  r.lang = recLang(); r.continuous = true; r.interimResults = true; r.maxAlternatives = 1;
  r.onresult = ev => { if (gen === recGen) onResult(ev); };
  r.onerror = e => {
    if (gen !== recGen || e.error === 'no-speech' || e.error === 'aborted') return;
    if (e.error === 'not-allowed') { running = false; setStatus(L('Microfone bloqueado. Clique em Iniciar para dar permissão.', 'Micrófono bloqueado. Haz clic en Iniciar para dar permiso.'), 'err'); }
    else setStatus(L('Aviso do reconhecimento: ' + e.error + ' (tentando de novo).', 'Aviso del reconocimiento: ' + e.error + ' (reintentando).'), 'warn');
  };
  r.onend = () => {
    if (gen !== recGen || !running) return;       // instância antiga (já substituída) não faz nada
    closeUnit(); sessResults = null; baseIdx = 0;
    const now = Date.now(); restarts = restarts.filter(t => now - t < 10000); restarts.push(now);
    // se está reiniciando rápido demais, espera mais (nunca desiste: a aula não pode ficar sem legenda)
    backoff = restarts.length > 8 ? Math.min(4000, backoff * 2) : 150;
    scheduleRec(backoff);
  };
  recStartAt = Date.now(); lastResultAt = Date.now();
  try { r.start(); } catch (e) { setStatus(L('Não consegui iniciar: ' + e.message + ' (tentando de novo).', 'No pude iniciar: ' + e.message + ' (reintentando).'), 'warn'); scheduleRec(1000); }
  return true;
}
function scheduleRec(ms) { setTimeout(() => { if (running) startRec(); }, ms); }
// Troca o reconhecimento por um novo, descartando o antigo (usado quando ele trava sem avisar).
function restartRec(why) {
  recRestarts++;
  const old = rec; recGen++;                      // invalida os eventos da instância antiga
  try { old && old.abort(); } catch (e) { /* ok */ }
  closeUnit(); sessResults = null; baseIdx = 0;
  setStatus(L('Reconhecimento reiniciado (' + why + ').', 'Reconocimiento reiniciado (' + why + ').'), 'warn');
  scheduleRec(250);
}

async function start() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
  } catch (e) {
    chrome.tabs.create({ url: chrome.runtime.getURL('perm.html') });
    setStatus(L('Permita o microfone na aba que abriu e depois clique em Iniciar de novo.', 'Permite el micrófono en la pestaña que se abrió y luego haz clic en Iniciar otra vez.'), 'warn');
    return;
  }
  actx = new AudioContext();
  const src = actx.createMediaStreamSource(stream);
  analyser = actx.createAnalyser(); analyser.fftSize = 2048; src.connect(analyser);
  const buf = new Float32Array(analyser.fftSize);
  lastAudioAt = Date.now();
  timers.push(setInterval(() => {
    analyser.getFloatTimeDomainData(buf);
    let e = 0; for (let i = 0; i < buf.length; i++) e += buf[i] * buf[i];
    level = Math.sqrt(e / buf.length);
    if (level > 0.005) lastAudioAt = Date.now();
    if (cur && level > cur.peak) cur.peak = level;
    const f0 = Core.estimateF0(buf, actx.sampleRate);
    const now = Date.now();
    if (f0) f0buf.push({ t: now, f0 });
    while (f0buf.length && f0buf[0].t < now - 90000) f0buf.shift();
  }, 70));
  timers.push(setInterval(() => {
    if (cur) {
      const idle = Date.now() - cur.lastAct, { allFinal } = segParts();
      if (idle > GAP_MS && allFinal) closeUnit();
      else if (idle > GAP_MS + 2500) { try { rec.stop(); } catch (e) { /* onend fecha */ } }
    }
    if (!running) return;
    const bars = Math.min(5, Math.round(level * 250));
    const idle = Date.now() - lastAudioAt;
    // vigia: tem som chegando mas o Chrome não devolve nada há muito tempo => ele travou; troca por um novo
    if (idle < 3000 && Date.now() - lastResultAt > 10000 && Date.now() - recStartAt > 10000) { restartRec(L('sem resposta há 10 s', 'sin respuesta hace 10 s')); return; }
    if (idle > 12000) setStatus(L('Sem áudio chegando. O microfone do Chrome precisa ser o "CABLE Output" e a aula deve tocar no "CABLE Input".', 'No llega audio. El micrófono de Chrome debe ser "CABLE Output" y la clase debe sonar en "CABLE Input".'), 'warn');
    else setStatus(L('Ouvindo · áudio ', 'Escuchando · audio ') + '▮'.repeat(bars) + '▯'.repeat(5 - bars) + (recRestarts || dropped ? L('  · reinícios: ', '  · reinicios: ') + recRestarts + L(' · ruído descartado: ', ' · ruido descartado: ') + dropped : ''));
  }, 400));
  running = true; restarts = []; recRestarts = 0; dropped = 0; backoff = 150;
  if (!startRec()) { stop(); return; }
  $('go').textContent = L('■ Parar', '■ Detener'); $('go').className = 'stop';
}

function stop() {
  running = false; recGen++;
  try { rec && rec.stop(); } catch (e) { /* ok */ }
  closeUnit(); sessResults = null; baseIdx = 0;
  timers.forEach(clearInterval); timers = [];
  try { stream && stream.getTracks().forEach(t => t.stop()); } catch (e) { /* ok */ }
  try { actx && actx.close(); } catch (e) { /* ok */ }
  $('go').textContent = '▶ Iniciar'; $('go').className = 'primary';
  setStatus(L('Parado. Clique em "Salvar" para baixar a aula.', 'Detenido. Haz clic en "Guardar" para descargar la clase.'));
}

// ---------- botões ----------
$('go').onclick = () => (running ? stop() : start());
$('uiBtn').onclick = () => { ui = ui === 'es' ? 'pt' : 'es'; try { localStorage.setItem('ui', ui); } catch (e) { /* ok */ } applyUi(); renderAll(); };
$('lang').onchange = () => { localStorage.setItem('lang', $('lang').value); if (running) { try { rec.stop(); } catch (e) { /* reinicia no onend */ } } };
$('showEs').onchange = () => { document.body.classList.toggle('showEs', $('showEs').checked); localStorage.setItem('showEs', $('showEs').checked ? '1' : '0'); };
$('mode').onchange = () => { const m = $('mode').value; localStorage.setItem('mode', m); setLang(m === 'auto' ? foreignLang() : m); };
$('dir').onchange = () => { dir = $('dir').value; localStorage.setItem('dir', dir); setLang($('mode').value === 'auto' ? foreignLang() : $('mode').value); };
$('onlyHi').onclick = () => { const on = document.body.classList.toggle('onlyHi'); $('onlyHi').classList.toggle('on', on); log.scrollTop = log.scrollHeight; };
let fs = +(localStorage.getItem('fs') || 18);
function applyFs() { document.documentElement.style.setProperty('--fs', fs + 'px'); localStorage.setItem('fs', fs); }
$('bigger').onclick = () => { fs = Math.min(40, fs + 2); applyFs(); };
$('smaller').onclick = () => { fs = Math.max(12, fs - 2); applyFs(); };
$('clear').onclick = () => {
  if (units.length && !confirm(L('Apagar tudo o que foi transcrito? Salve antes se quiser guardar.', '¿Borrar todo lo transcrito? Guarda antes si quieres conservarlo.'))) return;
  units = []; names = {}; startedAt = Date.now(); persist(); renderAll();
};
$('save').onclick = () => {
  closeUnit();
  chain.then(() => {
    const md = Core.toMarkdown(units, names, $('showEs').checked, startedAt, dirLabel(), ui);
    const d = new Date(startedAt), p = v => String(v).padStart(2, '0');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([md], { type: 'text/markdown;charset=utf-8' }));
    a.download = L('aula-', 'clase-') + d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '-' + p(d.getHours()) + 'h' + p(d.getMinutes()) + '.md';
    a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  });
};

// ---------- início ----------
(function init() {
  applyUi();
  $('lang').value = localStorage.getItem('lang') || 'es-UY';
  dir = localStorage.getItem('dir') === 'pt2es' ? 'pt2es' : 'es2pt'; $('dir').value = dir;
  $('mode').value = localStorage.getItem('mode') || 'auto'; setLang($('mode').value === 'auto' ? foreignLang() : $('mode').value);
  $('showEs').checked = localStorage.getItem('showEs') === '1';
  document.body.classList.toggle('showEs', $('showEs').checked);
  applyFs();
  try {
    chrome.storage.local.get(['units', 'names', 'startedAt'], v => {
      if (v && v.units && v.units.length) {
        units = v.units; names = v.names || {}; startedAt = v.startedAt || Date.now();
        renderAll(); setStatus(L('Aula anterior recuperada (' + units.length + ' frases). "Limpar" começa uma nova.', 'Clase anterior recuperada (' + units.length + ' frases). "Limpiar" empieza una nueva.'));
      }
    });
  } catch (e) { /* ok */ }
})();
