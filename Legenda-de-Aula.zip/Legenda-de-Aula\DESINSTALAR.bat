@echo off
title Legenda de Aula - Desinstalar
echo.
echo  Abrindo... / Abriendo...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\desinstalar.ps1"
