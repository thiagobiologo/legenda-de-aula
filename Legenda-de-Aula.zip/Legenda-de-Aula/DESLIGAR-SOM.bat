@echo off
title Legenda de Aula - Desligar escuta do cabo
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\configurar-som.ps1" -Desligar
