@echo off
title Legenda de Aula - Configurar som
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\configurar-som.ps1"
