﻿# Legenda de Aula - configura sozinho o "Escutar o dispositivo" do CABLE Output para sair no seu fone/caixa.
# Autor: Thiago Silva. Uso: CONFIGURAR-SOM.bat (liga) ou DESLIGAR-SOM.bat (desliga). Texto aberto, pode ler.
param([switch]$Desligar)
$ErrorActionPreference = 'Stop'
$pt = (Get-Culture).Name -like 'pt*'
function T($a, $b) { if ($pt) { $a } else { $b } }
function Say($m, $c = 'White') { Write-Host $m -ForegroundColor $c }

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
    Say (T 'Pedindo permissao de administrador... clique em Sim.' 'Pidiendo permiso de administrador... haz clic en Si.') Yellow
    $a = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    if ($Desligar) { $a += ' -Desligar' }
    Start-Process powershell -Verb RunAs -ArgumentList $a
    exit
}

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;

[StructLayout(LayoutKind.Sequential)] public struct PROPERTYKEY { public Guid fmtid; public int pid; }
[StructLayout(LayoutKind.Explicit, Size = 24)] public struct PROPVARIANT {
    [FieldOffset(0)] public ushort vt; [FieldOffset(8)] public IntPtr p; [FieldOffset(8)] public short b;
}
[ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IPropertyStore {
    int GetCount(out uint c); int GetAt(uint i, out PROPERTYKEY k);
    int GetValue(ref PROPERTYKEY k, out PROPVARIANT v); int SetValue(ref PROPERTYKEY k, ref PROPVARIANT v); int Commit();
}
[ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IMMDevice {
    int Activate(ref Guid id, int ctx, IntPtr p, [MarshalAs(UnmanagedType.IUnknown)] out object o);
    int OpenPropertyStore(int access, out IPropertyStore s);
    int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id); int GetState(out int st);
}
[ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IMMDeviceCollection { int GetCount(out uint c); int Item(uint i, out IMMDevice d); }
[ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IMMDeviceEnumerator {
    int EnumAudioEndpoints(int flow, int mask, out IMMDeviceCollection c);
    int GetDefaultAudioEndpoint(int flow, int role, out IMMDevice d);
}
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] public class MMDeviceEnumeratorCom { }

public static class Som {
    [DllImport("ole32.dll")] static extern int PropVariantClear(ref PROPVARIANT v);
    static PROPERTYKEY Key(string g, int pid) { PROPERTYKEY k = new PROPERTYKEY(); k.fmtid = new Guid(g); k.pid = pid; return k; }
    static string Nome(IMMDevice d) {
        IPropertyStore s; d.OpenPropertyStore(0, out s);
        PROPERTYKEY k = Key("a45c254e-df1c-4efd-8020-67d146a850e0", 2); PROPVARIANT v; s.GetValue(ref k, out v);
        string r = v.vt == 31 ? Marshal.PtrToStringUni(v.p) : ""; PropVariantClear(ref v); return r;
    }
    static string Id(IMMDevice d) { string i; d.GetId(out i); return i; }
    static List<IMMDevice> Lista(IMMDeviceEnumerator e, int flow) {
        IMMDeviceCollection c; e.EnumAudioEndpoints(flow, 1, out c); uint n; c.GetCount(out n);
        var l = new List<IMMDevice>(); for (uint i = 0; i < n; i++) { IMMDevice d; c.Item(i, out d); l.Add(d); } return l;
    }
    // devolve o nome do aparelho de saida usado, ou "" se nao achou o cabo
    public static string Configurar(bool ligar) {
        var e = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
        IMMDevice cabo = null;
        foreach (var d in Lista(e, 1)) if (Nome(d).IndexOf("CABLE Output", StringComparison.OrdinalIgnoreCase) >= 0) { cabo = d; break; }
        if (cabo == null) return "";
        string alvoId = ""; string alvoNome = "";
        if (ligar) {
            IMMDevice def = null; try { e.GetDefaultAudioEndpoint(0, 1, out def); } catch { }
            if (def != null && Nome(def).IndexOf("CABLE", StringComparison.OrdinalIgnoreCase) < 0 && Nome(def).IndexOf("VB-Audio", StringComparison.OrdinalIgnoreCase) < 0) { alvoId = Id(def); alvoNome = Nome(def); }
            else foreach (var d in Lista(e, 0)) { string n = Nome(d);
                if (n.IndexOf("CABLE", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("VB-Audio", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                if (n.IndexOf("Fone", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Head", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Auricular", StringComparison.OrdinalIgnoreCase) >= 0 || alvoId == "") { alvoId = Id(d); alvoNome = n; } }
            if (alvoId == "") return "";
        }
        IPropertyStore s; int hr = cabo.OpenPropertyStore(2, out s); if (hr != 0) throw new Exception("sem acesso " + hr);
        PROPERTYKEY kOn = Key("24dbb0fc-9311-4b3d-9cf0-18ff155639d4", 1), kDev = Key("24dbb0fc-9311-4b3d-9cf0-18ff155639d4", 0);
        PROPVARIANT vOn = new PROPVARIANT(); vOn.vt = 11; vOn.b = (short)(ligar ? -1 : 0); s.SetValue(ref kOn, ref vOn);
        PROPVARIANT vDev = new PROPVARIANT(); vDev.vt = 31; vDev.p = Marshal.StringToCoTaskMemUni(alvoId); s.SetValue(ref kDev, ref vDev);
        s.Commit(); Marshal.FreeCoTaskMem(vDev.p);
        return ligar ? alvoNome : "desligado";
    }
}
'@

try {
    $r = [Som]::Configurar(-not $Desligar)
    if ($r -eq '') {
        Say (T 'Nao achei o cabo de audio (CABLE Output). Reinicie o computador e tente de novo.' 'No encontre el cable de audio (CABLE Output). Reinicia la computadora e intenta de nuevo.') Red
    } elseif ($Desligar) {
        Say (T 'Pronto: o cabo nao toca mais no seu fone.' 'Listo: el cable ya no suena en tus auriculares.') Green
    } else {
        Say (T "Pronto! O som da aula vai sair em: $r" "Listo! El sonido de la clase saldra en: $r") Green
        Say (T 'Agora, na bandeja do relogio, escolha CABLE In 16 Ch como saida de som.' 'Ahora, en la bandeja del reloj, elige CABLE In 16 Ch como salida de sonido.')
    }
} catch {
    Say (T 'Nao consegui configurar sozinho. Siga o passo manual do guia.' 'No pude configurarlo solo. Sigue el paso manual de la guia.') Red
    Say $_.Exception.Message DarkGray
}
Read-Host (T 'Aperte Enter para fechar' 'Presiona Enter para cerrar')
