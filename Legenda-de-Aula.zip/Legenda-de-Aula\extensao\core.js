// Lógica pura (sem Chrome): altura da voz, agrupamento de falantes e exportação. Testável no Node.
(function (root) {
  const F0_MIN = 70, F0_MAX = 400, MIN_RMS = 0.012, MIN_PEAK = 0.45;

  // F0 em Hz de um bloco de áudio (autocorrelação normalizada) ou null se for silêncio/ruído.
  function estimateF0(x, sr) {
    const n = x.length;
    let mean = 0; for (let i = 0; i < n; i++) mean += x[i]; mean /= n;
    let e = 0; for (let i = 0; i < n; i++) { const v = x[i] - mean; e += v * v; }
    if (Math.sqrt(e / n) < MIN_RMS) return null;
    const lagMin = Math.floor(sr / F0_MAX), lagMax = Math.min(Math.floor(sr / F0_MIN), n - 2);
    let best = -1, bestLag = 0;
    for (let lag = lagMin; lag <= lagMax; lag++) {
      let s = 0;
      for (let i = 0; i + lag < n; i++) s += (x[i] - mean) * (x[i + lag] - mean);
      if (s > best) { best = s; bestLag = lag; }
    }
    if (best / e < MIN_PEAK) return null;
    return sr / bestLag;
  }

  function median(a) {
    const s = a.slice().sort((p, q) => p - q), m = s.length >> 1;
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  }

  // Agrupa por altura da voz (ln F0). Não é reconhecimento de pessoa: separa grave/agudo e
  // vozes bem diferentes. O usuário renomeia ("Fulana", "Professor") clicando no nome.
  class Speakers {
    constructor() { this.list = []; this.max = 4; this.dist = 0.25; this.minSamples = 8; this.last = null; this.pend = null; }
    assign(f0s) {
      if (f0s.length < this.minSamples) return this.last || this._make(null);
      const ln = Math.log(median(f0s));
      let best = null, bd = 1e9;
      for (const s of this.list) { const d = Math.abs(ln - s.ln); if (d < bd) { bd = d; best = s; } }
      const isNew = !best || (bd > this.dist && this.list.length < this.max);
      const cand = isNew ? 'new' : best.id;
      if (!this.last || (!isNew && best === this.last)) {      // mesma pessoa: segue
        this.pend = null;
        const s = this.last ? best : this._make(ln);
        if (this.last) { s.ln = (s.ln * s.n + ln) / (s.n + 1); s.n++; }
        return (this.last = s);
      }
      // outra voz: só troca depois de 2 frases seguidas apontando para a mesma (evita "pula-pula")
      if (this.pend && this.pend.cand === cand) this.pend.count++; else this.pend = { cand, count: 1 };
      if (this.pend.count < 2) return this.last;
      this.pend = null;
      const s = isNew ? this._make(ln) : best;
      if (!isNew) { s.ln = (s.ln * s.n + ln) / (s.n + 1); s.n++; }
      return (this.last = s);
    }
    _make(ln) {
      if (ln === null && this.list.length) return this.list[0];
      const id = this.list.length + 1;
      const s = { id, ln: ln === null ? Math.log(120) : ln, n: 1, name: 'Voz ' + id };
      this.list.push(s); return s;
    }
  }

  // Destaques por palavras-chave (sem IA, custo zero): prazos, trabalhos/avaliações e avisos do professor.
  const MESES_ES = 'enero|febrero|marzo|abril|mayo|junio|julio|agosto|se[p]?tiembre|octubre|noviembre|diciembre';
  const MESES_PT = 'janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro';
  const TAGDEF = {
    importante: { label: 'Importante', les: 'Importante',
      es: /\b(importante|fundamental|recuerd\w+|record\w+ que|tengan en cuenta|tener en cuenta|atenci[oó]n|no olviden|clave|obligatori\w+)\b/i,
      pt: /\b(importante|fundamental|lembr\w+|aten[cç][aã]o|n[aã]o esque[cç]\w+|obrigat[oó]ri\w+|levem em conta|ter em conta)\b/i },
    prazo: { label: 'Prazo / data', les: 'Plazo / fecha',
      es: new RegExp('\\b(entrega\\w*|entregar|plazo|vence\\w*|cronograma|pr[oó]xima clase|fecha de|\\d{1,2}\\s+de\\s+(' + MESES_ES + ')|d[ií]a\\s+\\d{1,2})\\b', 'i'),
      pt: new RegExp('\\b(entrega\\w*|entregar|prazo|vence\\w*|cronograma|pr[oó]xima aula|data de|\\d{1,2}\\s+de\\s+(' + MESES_PT + ')|dia\\s+\\d{1,2})\\b', 'i') },
    trabalho: { label: 'Trabalho / avaliação', les: 'Trabajo / evaluación',
      es: /\b(trabajo\s+(pr[aá]ctico|final|escrito|grupal)|examen\w*|parcial\w*|evaluaci[oó]n\w*|prueba\w*|tarea\w*|consigna\w*|r[uú]brica|integrantes|miembros|grupos?\s+de|bibliograf[ií]a|lectura obligatoria)\b/i,
      pt: /\b(trabalho\s+(pr[aá]tico|final|escrito|em grupo)|prova\w*|exame\w*|parcia(l|is)|avalia[cç][aã]o|avalia[cç][oõ]es|tarefa\w*|crit[eé]rio\w*|integrantes|membros|grupos?\s+de|bibliografia|leitura obrigat[oó]ria)\b/i }
  };
  function findTags(es, pt) {
    const out = [];
    const a = es || '', b = pt || '';
    for (const k of Object.keys(TAGDEF)) { const d = TAGDEF[k]; if (d.es.test(a) || d.es.test(b) || d.pt.test(a) || d.pt.test(b)) out.push(k); }
    return out;
  }
  const tagLabel = (k, ui) => (TAGDEF[k] ? (ui === 'es' ? TAGDEF[k].les : TAGDEF[k].label) : k);

  function fmtTime(ms) {
    const d = new Date(ms), p = v => String(v).padStart(2, '0');
    return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  }

  function toMarkdown(units, names, withEs, startedAt, dirLabel, ui) {
    const es = ui === 'es';
    const d = new Date(startedAt || Date.now());
    const lines = ['# ' + (es ? 'Clase' : 'Aula') + ' — ' + d.toLocaleDateString(es ? 'es' : 'pt-BR') + ' ' + fmtTime(d.getTime()), '',
      (es ? 'Transcripción automática (' : 'Transcrição automática (') + (dirLabel || 'espanhol → português') + (es ? '). Puede contener errores de reconocimiento.' : '). Pode conter erros de reconhecimento.'), ''];
    const hi = units.filter(u => u.tags && u.tags.length);
    if (hi.length) {
      lines.push(es ? '## Puntos importantes (destacados automáticamente)' : '## Pontos importantes (destacados automaticamente)', '');
      for (const u of hi) lines.push('- [' + fmtTime(u.t) + '] ' + u.tags.map(k => tagLabel(k, ui)).join(' · ') + ' — **' + (names[u.sp] || ('Voz ' + u.sp)) + '**: ' + (u.pt || u.es));
      lines.push('', es ? '## Transcripción completa' : '## Transcrição completa', '');
    }
    for (const u of units) {
      lines.push('**' + (names[u.sp] || ('Voz ' + u.sp)) + '** [' + fmtTime(u.t) + ']: ' + (u.pt || u.es));
      if (withEs && u.es) lines.push('> ' + u.es);
      lines.push('');
    }
    return lines.join('\n');
  }

  const api = { estimateF0, median, Speakers, fmtTime, toMarkdown, findTags, tagLabel };
  if (typeof module !== 'undefined') module.exports = api; else root.Core = api;
})(typeof self !== 'undefined' ? self : this);
