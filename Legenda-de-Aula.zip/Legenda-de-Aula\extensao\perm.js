const r = document.getElementById('r');
navigator.mediaDevices.getUserMedia({ audio: true }).then(s => {
  s.getTracks().forEach(t => t.stop());
  r.textContent = 'Pronto! Permissão concedida. Pode fechar esta aba e voltar para a barra lateral.';
}).catch(e => {
  r.textContent = 'Não foi permitido (' + e.name + '). Clique no cadeado ao lado do endereço e permita o microfone.';
});
