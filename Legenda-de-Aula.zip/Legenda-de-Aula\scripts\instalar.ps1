﻿# Legenda de Aula - instalador (Windows). Texto aberto: qualquer pessoa pode ler o que ele faz.
# O que faz: (1) copia a extensao para a sua pasta de usuario, (2) baixa o VB-CABLE do site OFICIAL
# e abre o instalador do proprio VB-CABLE para voce clicar em "Install Driver", (3) oferece reiniciar.
# Nao apaga nada, nao muda configuracoes do Windows, nao envia dados.
param([switch]$Teste)   # -Teste: mostra o que faria, sem instalar nada
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$es = (Get-UICulture).TwoLetterISOLanguageName -eq 'es'
function T($pt, $esx) { if ($es) { $esx } else { $pt } }
function Say($m, $c = 'White') { Write-Host $m -ForegroundColor $c }

Say ''
Say (T '=== Legenda de Aula: instalador ===' '=== Subtitulos de Clase: instalador ===') Cyan

# --- pede permissao de administrador (o driver de audio exige) ---
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin -and -not $Teste) {
    Say (T 'O Windows vai perguntar se pode fazer alteracoes. Clique em SIM.' 'Windows va a preguntar si permites cambios. Haz clic en SI.') Yellow
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$base = "$env:SystemDrive\LegendaDeAula"
$extSrc = Join-Path (Split-Path $PSScriptRoot -Parent) 'extensao'
$extDst = Join-Path $base 'extensao'
$cableDir = Join-Path $base 'vbcable'
$marker = Join-Path $base 'cabo-instalado-por-este-instalador.txt'

try {
    # --- passo 1: extensao ---
    Say ''
    Say (T '[1/3] Guardando a extensao no seu computador...' '[1/3] Guardando la extension en tu computadora...') Cyan
    if (-not (Test-Path (Join-Path $extSrc 'manifest.json'))) {
        throw (T 'Nao achei a pasta "extensao" ao lado do instalador. Extraia o .zip inteiro antes de abrir o INSTALAR.bat.' 'No encontre la carpeta "extensao" junto al instalador. Extrae todo el .zip antes de abrir INSTALAR.bat.')
    }
    if ($Teste) { Say "   (teste) copiaria $extSrc -> $extDst" DarkGray }
    else {
        New-Item -ItemType Directory -Force $base | Out-Null
        if (Test-Path $extDst) { Remove-Item $extDst -Recurse -Force }
        Copy-Item $extSrc $extDst -Recurse -Force
        Say ((T '   Pronto: ' '   Listo: ') + $extDst) Green
    }

    # --- passo 2: cabo de audio ---
    Say ''
    Say (T '[2/3] Cabo de audio (VB-CABLE)...' '[2/3] Cable de audio (VB-CABLE)...') Cyan
    $jaTem = Get-CimInstance Win32_SoundDevice -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*CABLE*' }
    if ($jaTem) {
        Say (T '   O cabo de audio ja esta instalado. Pulando.' '   El cable de audio ya esta instalado. Omitiendo.') Green
    } else {
        $urls = 'https://download.vb-audio.com/Download_CABLE/VBCABLE_Driver_Pack45.zip', 'https://download.vb-audio.com/Download_CABLE/VBCABLE_Driver_Pack43.zip'
        if ($Teste) {
            foreach ($u in $urls) { $r = Invoke-WebRequest $u -Method Head -UseBasicParsing; Say "   (teste) $u -> $($r.StatusCode)" DarkGray }
        } else {
            Say (T '   Baixando do site oficial (vb-audio.com), uns 1,3 MB...' '   Descargando del sitio oficial (vb-audio.com), unos 1,3 MB...')
            $tmp = Join-Path $env:TEMP 'LegendaDeAula'; New-Item -ItemType Directory -Force $tmp | Out-Null
            $zip = Join-Path $tmp 'vbcable.zip'; $ok = $false
            foreach ($u in $urls) { try { Invoke-WebRequest $u -OutFile $zip -UseBasicParsing; $ok = $true; break } catch { } }
            if (-not $ok) { throw (T 'Nao consegui baixar. Confira a internet e tente de novo.' 'No pude descargar. Revisa tu internet e intenta de nuevo.') }
            if (Test-Path $cableDir) { Remove-Item $cableDir -Recurse -Force }
            Expand-Archive $zip $cableDir -Force
            $setup = if ($env:PROCESSOR_ARCHITECTURE -eq 'x86') { 'VBCABLE_Setup.exe' } else { 'VBCABLE_Setup_x64.exe' }
            Say ''
            Say (T '   VAI ABRIR A JANELA DO VB-CABLE. Nela, faca assim:' '   SE ABRE LA VENTANA DE VB-CABLE. En ella, haz asi:') Yellow
            Say (T '     1) Clique em "Install Driver"' '     1) Haz clic en "Install Driver"') Yellow
            Say (T '     2) Se o Windows perguntar sobre o software do dispositivo, clique em Instalar' '     2) Si Windows pregunta por el software del dispositivo, haz clic en Instalar') Yellow
            Say (T '     3) Clique em OK quando terminar. Pode demorar alguns segundos.' '     3) Haz clic en OK al terminar. Puede tardar unos segundos.') Yellow
            Start-Process (Join-Path $cableDir $setup) -Wait
            Set-Content $marker 'VB-CABLE instalado pelo instalador do Legenda de Aula.' -Encoding UTF8
            Say (T '   Cabo de audio instalado (falta reiniciar).' '   Cable de audio instalado (falta reiniciar).') Green
        }
    }

    # --- passo 3: reiniciar ---
    Say ''
    Say (T '[3/3] Proximo passo: REINICIAR o computador.' '[3/3] Siguiente paso: REINICIAR la computadora.') Cyan
    Say (T '   Sem reiniciar, o Windows nao reconhece o cabo de audio novo.' '   Sin reiniciar, Windows no reconoce el cable de audio nuevo.')
    Say (T '   Depois de reiniciar, volte ao guia e siga do passo 5.' '   Despues de reiniciar, vuelve a la guia y sigue desde el paso 5.')
    Say ((T '   A extensao esta em: ' '   La extension esta en: ') + $extDst + (T '   (nao apague esta pasta)' '   (no borres esta carpeta)')) Green
    if ($Teste) { Say '(teste) terminou sem instalar nada.' DarkGray; exit }
    Say ''
    $r = Read-Host (T 'Reiniciar agora? Digite S e Enter (ou so Enter para reiniciar depois)' 'Reiniciar ahora? Escribe S y Enter (o solo Enter para reiniciar despues)')
    if ($r -match '^[sSyY]') {
        Say (T 'Reiniciando em 20 segundos. Para cancelar, abra o Prompt de Comando e digite: shutdown /a' 'Reiniciando en 20 segundos. Para cancelar, abre el Simbolo del sistema y escribe: shutdown /a') Yellow
        shutdown /r /t 20 /c "Legenda de Aula: reiniciando para ativar o cabo de audio"
    }
}
catch {
    Say ''
    Say ((T 'ALGO DEU ERRADO: ' 'ALGO SALIO MAL: ') + $_.Exception.Message) Red
    Say (T 'Nada foi apagado. Pode abrir o INSTALAR.bat de novo.' 'No se borro nada. Puedes abrir INSTALAR.bat de nuevo.') Red
}
Read-Host (T 'Pressione Enter para fechar' 'Presiona Enter para cerrar') | Out-Null
