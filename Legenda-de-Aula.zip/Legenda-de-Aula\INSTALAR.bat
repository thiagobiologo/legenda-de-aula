@echo off
title Legenda de Aula - Instalador
echo.
echo  Abrindo o instalador... / Abriendo el instalador...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\instalar.ps1"
