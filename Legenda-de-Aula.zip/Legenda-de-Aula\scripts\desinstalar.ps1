﻿# Legenda de Aula - desinstalador. So desfaz o que o instalador fez.
param([switch]$Teste)
$ErrorActionPreference = 'Stop'
$es = (Get-UICulture).TwoLetterISOLanguageName -eq 'es'
function T($pt, $esx) { if ($es) { $esx } else { $pt } }
function Say($m, $c = 'White') { Write-Host $m -ForegroundColor $c }

Say ''
Say (T '=== Legenda de Aula: desinstalar ===' '=== Subtitulos de Clase: desinstalar ===') Cyan

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin -and -not $Teste) {
    Say (T 'O Windows vai perguntar se pode fazer alteracoes. Clique em SIM.' 'Windows va a preguntar si permites cambios. Haz clic en SI.') Yellow
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$base = Join-Path $HOME 'LegendaDeAula'
$marker = Join-Path $base 'cabo-instalado-por-este-instalador.txt'
$cableDir = Join-Path $base 'vbcable'

try {
    Say (T 'Isto vai remover a pasta da extensao e, se foi este instalador que colocou, o cabo de audio.' 'Esto quitara la carpeta de la extension y, si lo instalo este instalador, el cable de audio.')
    if ($Teste) { Say "(teste) pasta: $base ; cabo por este instalador: $(Test-Path $marker)" DarkGray; exit }
    $r = Read-Host (T 'Continuar? Digite S e Enter' 'Continuar? Escribe S y Enter')
    if ($r -notmatch '^[sSyY]') { Say (T 'Cancelado. Nada foi alterado.' 'Cancelado. No se cambio nada.'); exit }

    if ((Test-Path $marker) -and (Test-Path (Join-Path $cableDir 'VBCABLE_Setup_x64.exe'))) {
        Say ''
        Say (T 'VAI ABRIR A JANELA DO VB-CABLE. Clique em "Remove Driver" e depois em OK.' 'SE ABRE LA VENTANA DE VB-CABLE. Haz clic en "Remove Driver" y luego en OK.') Yellow
        $setup = if ($env:PROCESSOR_ARCHITECTURE -eq 'x86') { 'VBCABLE_Setup.exe' } else { 'VBCABLE_Setup_x64.exe' }
        Start-Process (Join-Path $cableDir $setup) -Wait
    } else {
        Say (T 'O cabo de audio nao foi colocado por este instalador, entao nao mexi nele.' 'El cable de audio no lo puso este instalador, asi que no lo toque.')
    }
    # so apaga a pasta do proprio programa, dentro do seu usuario
    if ((Test-Path $base) -and ((Split-Path $base -Leaf) -eq 'LegendaDeAula') -and ($base.StartsWith($HOME))) {
        Remove-Item $base -Recurse -Force
        Say (T 'Pasta da extensao removida.' 'Carpeta de la extension eliminada.') Green
    }
    Say ''
    Say (T 'Falta so um passo: no Chrome, abra chrome://extensions, ache "Legenda de Aula" e clique em Remover.' 'Falta un paso: en Chrome abre chrome://extensions, busca "Subtitulos de Clase" y haz clic en Quitar.') Yellow
    Say (T 'Se removeu o cabo de audio, reinicie o computador para concluir.' 'Si quitaste el cable de audio, reinicia la computadora para terminar.')
}
catch { Say ((T 'ALGO DEU ERRADO: ' 'ALGO SALIO MAL: ') + $_.Exception.Message) Red }
Read-Host (T 'Pressione Enter para fechar' 'Presiona Enter para cerrar') | Out-Null
